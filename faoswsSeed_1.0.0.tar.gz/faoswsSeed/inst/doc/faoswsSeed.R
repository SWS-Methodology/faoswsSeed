## ----setup, include=FALSE, cache=FALSE, echo=FALSE----------------------------
library(knitr)
opts_chunk$set(fig.path = 'figure/', fig.align = 'center', fig.show = 'hold',
               warning = FALSE, message = FALSE, error = FALSE, tidy = FALSE,
               results = 'markup', eval = FALSE, echo = TRUE, cache = FALSE)
options(replace.assign = TRUE, width = 80)
assign("depthtrigger", 10, data.table:::.global)

## ----loda-library, eval=TRUE--------------------------------------------------
## Load libraries
library(faosws)
#library(faoswsSeed)
files = dir("~/Documents/Github/sws_seed/faoswsSeed/R/", full.names = TRUE)
for(file in files) source(file)
library(faoswsUtil)
library(faoswsFlag)
library(data.table)
library(ggplot2)

## -----------------------------------------------------------------------------
#  ## Pull in necessary swsContext parameters, see faosws documentation
#  GetTestEnvironment(
#      baseUrl = "https://hqlqasws1.hq.un.fao.org:8181/sws",
#      token = "ec5a4b0e-0ffa-432e-9db0-ba08072c924b"
#  )

## -----------------------------------------------------------------------------
#  swsContext.datasets[[1]]@dimensions$geographicAreaM49@keys = c("40")

## -----------------------------------------------------------------------------
#  data = getAreaData(dataContext = swsContext.datasets[[1]],
#                     areaSownElementCode = "5212",
#                     areaHarvestedElementCode = "5312",
#                     seedElementCode = "5525")
#  head(data, 1)

## -----------------------------------------------------------------------------
#  data[, Value_measuredElement_5212]
#  imputeAreaSown(data = data)
#  data[, Value_measuredElement_5212]
#  data[, Value_measuredElement_5312]

## -----------------------------------------------------------------------------
#  countrySpecificData = getCountrySpecificSeedRate()
#  head(countrySpecificData, 3)
#  data = fillCountrySpecificSeedRate(data = data,
#      countrySpecificData = countrySpecificData)
#  head(data, 1)
#  data[, Value_seedRate]

## -----------------------------------------------------------------------------
#  generalSeedData = getCountryGeneralSeedRate()
#  head(generalSeedData, 3)
#  data = fillGeneralSeedRate(data = data,
#      generalSeedData = generalSeedData)
#  head(data, 1)
#  data[, Value_seedRate]

## -----------------------------------------------------------------------------
#  data[, Value_measuredElement_5525]
#  imputeSeed(data)
#  data[, Value_measuredElement_5525]
#  data[, Value_measuredElement_5312]

## -----------------------------------------------------------------------------
#  saveSeedData(data)

